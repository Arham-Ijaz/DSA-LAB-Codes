#pragma once

#include <iostream>
#include <string>
#include "Node.h"
#include"Patient.h"
using namespace std;



template <typename T>
class PatientQueue {
private:
    Node<T>* head;
    Node<T>* tail;

public:
    PatientQueue() : head(nullptr), tail(nullptr) {}

    void AddPatient(T patient) {
        Node<T>* newNode = new Node<T>(patient);
        if (!head) {
            head = tail = newNode;
        }
        else {
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    }

    void RemovePatient(int id) {
        Node<T>* current = head;
        while (current && current->data.id != id) {
            current = current->next;
        }
        if (!current) {
            cout << "Patient with ID " << id << " not found.\n";
            return;
        }
        if (current == head) {
            head = head->next;
            if (head) {
                head->prev = nullptr;
            }
            else {
                tail = nullptr;
            }
        }
        else if (current == tail) {
            tail = tail->prev;
            tail->next = nullptr;
        }
        else {
            current->prev->next = current->next;
            current->next->prev = current->prev;
        }
        delete current;
        cout << "Patient with ID " << id << " removed.\n";
    }

    void DisplayPatients() {
        if (!head) {
            cout << "Queue is empty.\n";
            return;
        }
        Node<T>* current = head;
        cout << "Current Patient Queue:\n";
        while (current) {
            cout << current->data << "\n";
            current = current->next;
        }
    }

    int CountPatients() {
        int count = 0;
        Node<T>* current = head;
        while (current) {
            ++count;
            current = current->next;
        }
        return count;
    }

    ~PatientQueue() {
        Node<T>* current = head;
        while (current) {
            Node<T>* next = current->next;
            delete current;
            current = next;
        }
        head = tail = nullptr;
    }
};
