#pragma once

#include<iostream>
#include<string>
using namespace std;

class Patient{
public:
    int id;
    string name;
    Patient() { }
    Patient(const int & id, const string & name) : id(id), name(name) {}

    friend ostream& operator<<(ostream& os, const Patient& p) {
        os << "ID: " << p.id << ", Name: " << p.name;
        return os;
    }

    bool operator==(const Patient& other) const {
        return id == other.id;
    }
};