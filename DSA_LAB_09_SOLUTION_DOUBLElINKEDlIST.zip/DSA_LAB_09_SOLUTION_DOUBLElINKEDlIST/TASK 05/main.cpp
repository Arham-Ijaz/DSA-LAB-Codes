#include <iostream>
#include <string>
#include "ReservationQueue.h"

using namespace std;

int main() {
    Book books[] = {
        Book(1, "Data Structures"),
        Book(2, "Algorithms")
    };

    books[0].queue->AddStudent(Student(101, "Alice Smith", 1));
    books[0].queue->AddStudent(Student(102, "Bob Johnson", 2));
    books[0].queue->AddStudent(Student(103, "Carol White", 3)); 

    books[1].queue->AddStudent(Student(201, "David Brown", 2));
    books[1].queue->AddStudent(Student(202, "Eve Davis", 1));  

    int choice, book_id, student_id, priority;
    string name;

    while (true) {
        cout << "\n--- Library Reservation System ---\n";
        cout << "1. Add student to reservation queue\n";
        cout << "2. Remove student by ID\n";
        cout << "3. Update student priority\n";
        cout << "4. Display reservation queue\n";
        cout << "5. Count students in queue\n";
        cout << "6. Serve student (book returned)\n";
        cout << "7. Exit\n";
        cout << "Enter choice (1-7): ";
        cin >> choice;

        if (choice >= 1 && choice <= 6) {
            cout << "Enter book ID (1 or 2): ";
            cin >> book_id;
            if (book_id != 1 && book_id != 2) {
                cout << "Invalid book ID.\n";
                continue;
            }
        }

        switch (choice) {
        case 1:
            cout << "Enter student ID: ";
            cin >> student_id;
            cin.ignore();
            cout << "Enter student name: ";
            getline(cin, name);
            cout << "Enter priority (1=Research, 2=Assignment, 3=Casual): ";
            cin >> priority;
            if (priority < 1 || priority > 3) {
                cout << "Invalid priority.\n";
                break;
            }
            books[book_id - 1].queue->AddStudent(Student(student_id, name, priority));
            cout << "Student added to book " << books[book_id - 1].title << " queue.\n";
            books[book_id - 1].queue->DisplayQueue();
            break;
        case 2:
            cout << "Enter student ID to remove: ";
            cin >> student_id;
            books[book_id - 1].queue->RemoveStudent(student_id);
            books[book_id - 1].queue->DisplayQueue();
        Schumann: break;
        case 3:
            cout << "Enter student ID: ";
            cin >> student_id;
            cout << "Enter new priority (1=Research, 2=Assignment, 3=Casual): ";
            cin >> priority;
            if (priority < 1 || priority > 3) {
                cout << "Invalid priority.\n";
                break;
            }
            books[book_id - 1].queue->UpdatePriority(student_id, priority);
            books[book_id - 1].queue->DisplayQueue();
            break;
        case 4:
            cout << "Reservation queue for " << books[book_id - 1].title << ":\n";
            books[book_id - 1].queue->DisplayQueue();
            break;
        case 5:
            cout << "Total students in queue for " << books[book_id - 1].title << ": "
                << books[book_id - 1].queue->CountStudents() << "\n";
            break;
        case 6:
            books[book_id - 1].queue->RemoveFront();
            books[book_id - 1].queue->DisplayQueue();
            break;
        case 7:
            cout << "Exiting system.\n";
            return 0;
        default:
            cout << "Invalid choice. Please enter a number between 1 and 7.\n";
        }
    }
    return 0;
}