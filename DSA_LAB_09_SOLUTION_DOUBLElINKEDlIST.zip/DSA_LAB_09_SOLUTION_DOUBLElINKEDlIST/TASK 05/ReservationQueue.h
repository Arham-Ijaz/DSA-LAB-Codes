#pragma once

#include "Node.h"
#include <iostream>
#include <string>

using namespace std;




class Student {
public:
    int id;
    string name;
    int priority; 

    Student(int id, string name, int priority) : id(id), name(name), priority(priority) {}

    friend ostream& operator<<(ostream& os, const Student& s) {
        string priority_str = s.priority == 1 ? "Research" : s.priority == 2 ? "Assignment" : "Casual";
        os << "ID: " << s.id << ", Name: " << s.name << ", Priority: " << priority_str;
        return os;
    }

    bool operator==(const Student& other) const {
        return id == other.id;
    }
};


template <typename T>
class ReservationQueue {
private:
    Node<T>* head;
    Node<T>* tail;

public:
    ReservationQueue() : head(nullptr), tail(nullptr) {}

    void AddStudent(T student) {
        Node<T>* newNode = new Node<T>(student);
        if (!head) {
            head = tail = newNode;
            return;
        }
        Node<T>* current = head;
        while (current && current->data.priority <= student.priority) {
            current = current->next;
        }
        if (!current) { 
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        else if (current == head) { 
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
        else { 
            newNode->prev = current->prev;
            newNode->next = current;
            current->prev->next = newNode;
            current->prev = newNode;
        }
    }


    void RemoveStudent(int id) {
        Node<T>* current = head;
        while (current && current->data.id != id) {
            current = current->next;
        }
        if (!current) {
            cout << "Student with ID " << id << " not found.\n";
            return;
        }
        if (current == head) {
            head = head->next;
            if (head) {
                head->prev = nullptr;
            }
            else {
                tail = nullptr;
            }
        }
        else if (current == tail) {
            tail = tail->prev;
            tail->next = nullptr;
        }
        else {
            current->prev->next = current->next;
            current->next->prev = current->prev;
        }
        delete current;
        cout << "Student with ID " << id << " removed.\n";
    }

    void UpdatePriority(int id, int new_priority) {
        Node<T>* current = head;
        while (current && current->data.id != id) {
            current = current->next;
        }
        if (!current) {
            cout << "Student with ID " << id << " not found.\n";
            return;
        }
        T student = current->data;
        student.priority = new_priority;
        RemoveStudent(id); 
        AddStudent(student);
        cout << "Priority updated for student ID " << id << ".\n";
    }

    void DisplayQueue() {
        if (!head) {
            cout << "Reservation queue is empty.\n";
            return;
        }
        Node<T>* current = head;
        cout << "Reservation Queue:\n";
        while (current) {
            cout << current->data << "\n";
            current = current->next;
        }
    }

    int CountStudents() {
        int count = 0;
        Node<T>* current = head;
        while (current) {
            ++count;
            current = current->next;
        }
        return count;
    }

    void RemoveFront() {
        if (!head) {
            cout << "Queue is empty.\n";
            return;
        }
        Node<T>* temp = head;
        cout << "Serving student: " << temp->data << "\n";
        head = head->next;
        if (head) {
            head->prev = nullptr;
        }
        else {
            tail = nullptr;
        }
        delete temp;
    }

    // Destructor
    ~ReservationQueue() {
        Node<T>* current = head;
        while (current) {
            Node<T>* next = current->next;
            delete current;
            current = next;
        }
        head = tail = nullptr;
    }
};
class Book {
public:
    int book_id;
    string title;
    ReservationQueue<Student>* queue;

    Book(int id, string title) : book_id(id), title(title), queue(new ReservationQueue<Student>()) {}

    ~Book() {
        delete queue;
    }
};

