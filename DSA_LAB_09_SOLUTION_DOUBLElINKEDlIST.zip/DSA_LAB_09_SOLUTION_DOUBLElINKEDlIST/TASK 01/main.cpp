#include <iostream>
using namespace std;
#include "Node.h"
#include "DoubleLinkedList.h"

int main() {
    DoubleLinkedList<int> list;
    int choice, value, pos;

    while (true) {
        cout << "\n--- Doubly Linked List Menu ---\n";
        cout << "1. Insert at position\n";
        cout << "2. Delete at position\n";
        cout << "3. Search for an element\n";
        cout << "4. Count total nodes\n";
        cout << "5. Display list\n";
        cout << "6. Exit\n";
        cout << "Enter choice (1-6): ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value to insert: ";
            cin >> value;
            cout << "Enter position (1-based): ";
            cin >> pos;
            list.InsertAtPosition(value, pos);
            list.Display();
            break;
        case 2:
            cout << "Enter position to delete (1-based): ";
            cin >> pos;
            list.DeleteAtPosition(pos);
            list.Display();
            break;
        case 3:
            cout << "Enter value to search: ";
            cin >> value;
            list.Search(value);
            break;
        case 4:
            cout << "Total nodes: " << list.CountNodes() << "\n";
            break;
        case 5:
            list.Display();
            break;
        case 6:
            cout << "Exiting program.\n";
            return 0;
        default:
            cout << "Invalid choice. Please enter a number between 1 and 6.\n";
        }
    }
    return 0;
}