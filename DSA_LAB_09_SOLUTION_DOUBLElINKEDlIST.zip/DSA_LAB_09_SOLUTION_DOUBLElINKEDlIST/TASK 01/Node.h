#pragma once

template<class T> 

class Node {
public:

	Node* next;
	Node* prev;
	T data;


	Node(const T & _data = 0):data(_data),next(nullptr),prev(
		nullptr){}

};