#pragma once

#include "Node.h"
template <class T>
class DoubleLinkedList {

private:

	Node<T>* head;
	Node<T>* tail;
public:
	DoubleLinkedList():head(nullptr),tail(nullptr) {}
	
	void insertAtBeginning(const T& value) {
		Node<T>* newNode = new Node<T>(value);

		if (!head) {
			head = tail = newNode;
		}
		else {
			newNode->next = head;
			head->prev = newNode;
			head = newNode;
		}


	}
	
	void insertAtEnd(const T& value) {
		Node<T>* newNode = new Node<T>(value);

		if (!head) {
			head = tail = newNode;
		}
		else {
			tail->next = newNode;
			newNode->prev = tail;
			tail = newNode;
		}


	}
	void DeleteByValue(T value) {
		Node<T>* current = head;
		while (current && current->data != value) {
			current = current->next;
		}
		if (!current) {
		cout << "Value " << value << " not found\n";
			return;
		}
		if (current == head) {
			head = head->next;
			if (head) head->prev = nullptr;
			else tail = nullptr;
		}
		else if (current == tail) {
			tail = tail->prev;
			tail->next = nullptr;
		}
		else {
			current->prev->next = current->next;
			current->next->prev = current->prev;
		}
		delete current;
	}
    void InsertAtPosition(T value, int pos) {
        if (pos < 1) {
               cout << "Invalid position. Position must be >= 1.\n";
            return;
        }
        Node<T>* newNode = new Node<T>(value);
        if (pos == 1) {
            newNode->next = head;
            if (head) {
                head->prev = newNode;
            }
            head = newNode;
            if (!tail) {
                tail = newNode;
            }
            return;
        }
        Node<T>* current = head;
        for (int i = 1; i < pos - 1 && current; ++i) {
            current = current->next;
        }
        if (!current) {
              cout << "Position out of range.\n";
            delete newNode;
            return;
        }
        newNode->next = current->next;
        newNode->prev = current;
        if (current->next) {
            current->next->prev = newNode;
        }
        else {
            tail = newNode;
        }
        current->next = newNode;
    }

    void DeleteAtPosition(int pos) {
        if (!head || pos < 1) {
              cout << "Invalid position or empty list.\n";
            return;
        }
        Node<T>* current = head;
        if (pos == 1) {
            head = head->next;
            if (head) {
                head->prev = nullptr;
            }
            else {
                tail = nullptr;
            }
            delete current;
            return;
        }
        for (int i = 1; i < pos && current; ++i) {
            current = current->next;
        }
        if (!current) {
           cout << "Position out of range.\n";
            return;
        }
        current->prev->next = current->next;
        if (current->next) {
            current->next->prev = current->prev;
        }
        else {
            tail = current->prev;
        }
        delete current;
    }

    bool Search(T value) {
        Node<T>* current = head;
        int pos = 1;
        while (current) {
            if (current->data == value) {
           cout << value << " found at position " << pos << ".\n";
                return true;
            }
            current = current->next;
            ++pos;
        }
       cout << value << " not found in the list.\n";
        return false;
    }

    int CountNodes() {
        int count = 0;
        Node<T>* current = head;
        while (current) {
            ++count;
            current = current->next;
        }
        return count;
    }

  

    ~DoubleLinkedList() {
        Node<T>* current = head;
        while (current) {
            Node<T>* next = current->next;
            delete current;
            current = next;
        }
        head = tail = nullptr;
    }


	void Display() {
		if (!head) {
			cout << "Double Linked List is Empty..\n";
			return;
		}
		Node<T>* current = head;
		while (current) {
			cout << current->data << " ";
			current = current->next;
		}
		cout << "\n";

	}

};