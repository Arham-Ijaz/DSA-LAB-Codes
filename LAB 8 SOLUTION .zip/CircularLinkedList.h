template <typename T>
class CircularLinkedList {
private:
    Node<T>* head;
public:
    CircularLinkedList() : head(nullptr) {}

    void append(T data) {
        Node<T>* new_node = new Node<T>(data);
        if (!head) {
            head = new_node;
            new_node->next = head;
        }
        else {
            Node<T>* temp = head;
            while (temp->next != head) {
                temp = temp->next;
            }
            temp->next = new_node;
            new_node->next = head;
        }
    }

    T get_survivor(T start, int k) {
        if (!head) return -1; 

        Node<T>* current = head;
        while (current->data != start) {
            current = current->next;
            if (current == head) return -1;
        }

        while (current->next != current) {
            for (int i = 0; i < k; i++) {
                current = current->next;
            }

            Node<T>* node_to_delete = current->next;
            current->next = node_to_delete->next;
            if (node_to_delete == head) {
                head = current->next;
            }
            cout << "Person " << node_to_delete->data << " was executed." << endl;
            delete node_to_delete;
        }

        head = current;
        return current->data;
    }

    ~CircularLinkedList() {
        if (!head) return;

        Node<T>* current = head->next;
        while (current != head) {
            Node<T>* temp = current;
            current = current->next;
            delete temp;
        }
        delete head;
    }
};

