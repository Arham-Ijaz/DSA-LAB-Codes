// Data Structure Used: Singly Circular Linked List

/*
Algorithm:
1. Start from the given starting person
2. Traverse k nodes (skipping k people)
3. Remove the next node (execute the person)
4. Continue the process from the next node of the removed node
5. Repeat until only one node remains

*/
#include <iostream>
using namespace std;
#include"Node.h"
#include"CircularLinkedList.h"



int main() {
    CircularLinkedList<int> circle;
    int choice;
    int n, start, k;
    int last_survivor = -1;

    do {
        cout << "Menu:\n";
        cout << "1. Start the game\n";
        cout << "2. Exit the program\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            if (last_survivor != -1) {
                cout << "Last game's survivor was: " << last_survivor << endl;
            }

            cout << "Enter number of people: ";
            cin >> n;
            cout << "Enter starting person: ";
            cin >> start;
            cout << "Enter number of people to skip: ";
            cin >> k;

            // Create the circle
            for (int i = 1; i <= n; i++) {
                circle.append(i);
            }

            last_survivor = circle.get_survivor(start, k);
            cout << "\nThe survivor is: " << last_survivor << endl;
            break;

        case 2:
            cout << "Exiting program.\n";
            break;

        default:
            cout << "Invalid choice. Please try again.\n";
        }
    } while (choice != 2);

    return 0;
}