#pragma once
#include<iostream>
#include<string>
using namespace std;
#include"Stack.h"

template<class T>
class MyStack:public Stack<T>
{
public:
	MyStack(int  _size):Stack<T>(_size){}
	void push(T value) { Stack<T>::push(value); }
	T pop() { return Stack<T>::pop(); }
	T top() { return Stack<T>::top(); }
	bool isEmpty() { return Stack<T>::isEmpty(); }
	bool isFull() { return Stack<T>::isFull(); }

	void display() {Stack<T>::display();}
};