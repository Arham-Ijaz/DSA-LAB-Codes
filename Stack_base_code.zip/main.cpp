#include <iostream>
#include<string>

#include "MyStack.h"
using namespace std;

int main()
{
	MyStack <int> obj(10);
	int array[]{ 1,2,3,4,5,6,7 };
	for (int i = 0;i < 7;i++) {

	obj.push(array[i]);
	}
	cout << "Top = " << obj.top() << endl;
	obj.display();


	MyStack <int> obj1(5);
	obj1.push(15);
	obj1.push(99);
	obj1.push(888);
	obj1.push(-33);
	cout << "Top = " << obj1.top() << endl;
	obj1.display();

	cout << endl << endl << endl;

	MyStack<char> obj2(100);
	obj2.push('A');
	obj2.push(48);
	obj2.push('B');
	obj2.push(20);
	obj2.display();

	MyStack<string> obj3(15);
	obj3.push("daniyal");
	obj3.display();
	return 0;
}
