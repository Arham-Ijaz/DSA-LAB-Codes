#pragma once


#include<iostream>
#include<string>
using namespace std;
template<class T>

class Stack {
private:

	T* arr;
	int maxSize;
	int currentSize;

public:

	virtual void push(T value) = 0;
	virtual T pop() = 0;
	virtual T top() = 0;
	virtual bool isEmpty() = 0;
	virtual bool isFull() = 0;

	Stack(int );
	void display();

};
template<class T>
 Stack<T> :: Stack(int _size) {
	 maxSize = _size;
	 arr = new T[maxSize];
	 currentSize = 0;


}
 template < class T>
 void Stack<T>::push(T value)
 {
	 if (!isFull()) {
		 arr[currentSize] = value;
		 currentSize++;
	 }
	 else {
		 cout << "Stack is Full." << endl;

	 }
 }


 template < class T>
 T Stack<T>:: pop() {
	 if (!isEmpty()) {
		 return arr[--currentSize];
	 }
	 else {
		 cout << "Stack is Empty.\n";
		 return T();
	 }
 }


 template < class T>
 T Stack<T>::top(){
	 if (!isEmpty()) {
		 return arr[currentSize - 1];
	 }
	 else {
		 cout << "Stack is Empty.\n";
		 return T();
	 }
 }


 template < class T>
 bool Stack<T> :: isEmpty()
 {
	 if (currentSize == 0) {
		 return true;
	 }
	 else {
		 return false;
	 }
 }


 template < class T>
 bool Stack<T> :: isFull() {
	 if (currentSize == maxSize) {
		 return true;
	 }
	 else {
		 return false;
	 }
 }

 template <class T>
 void Stack<T>::display() {
	 cout << "The Max Size of Stack is: " << maxSize << endl;
	 cout << "The Current Filled Size of Stack is: " << currentSize << endl;
	 for (int i = 0;i < currentSize;i++) {
		 cout << i << ".  " << arr[i]<<endl;
	 }
 }